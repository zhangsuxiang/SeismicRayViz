#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Enhanced 3D Seismic Ray Path Visualization with Realistic Ray Tracing
Implements separate P-wave and S-wave visualizations with physically-based ray paths

This module can be integrated with the existing seismic_visualization.py
or used as a standalone enhancement for 3D visualization.
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Line3DCollection
from matplotlib.lines import Line2D
import warnings
warnings.filterwarnings('ignore')


class RealisticRayTracer:
    """
    Implements realistic ray path calculation based on velocity models
    using simplified ray theory for 1D Earth model
    """
    
    def __init__(self):
        """Initialize with a simplified 1D velocity model"""
        # Define 1D velocity model (simplified IASP91/AK135-like model)
        # Depths in km, velocities in km/s
        self.depth_layers = np.array([0, 5, 10, 15, 20, 25, 35, 50, 100, 200, 400, 600])
        
        # P-wave velocities (km/s)
        self.vp_model = np.array([
            5.8,   # Surface
            6.0,   # 5 km
            6.3,   # 10 km
            6.5,   # 15 km
            6.7,   # 20 km (Conrad discontinuity region)
            6.9,   # 25 km
            8.0,   # 35 km (Moho)
            8.1,   # 50 km (upper mantle)
            8.2,   # 100 km
            8.5,   # 200 km
            9.5,   # 400 km
            10.5   # 600 km
        ])
        
        # S-wave velocities (km/s) - approximately Vp/1.73
        self.vs_model = np.array([
            3.4,   # Surface
            3.5,   # 5 km
            3.65,  # 10 km
            3.75,  # 15 km
            3.85,  # 20 km
            3.95,  # 25 km
            4.5,   # 35 km (Moho)
            4.6,   # 50 km
            4.7,   # 100 km
            4.9,   # 200 km
            5.4,   # 400 km
            6.0    # 600 km
        ])
        
    def calculate_ray_path(self, source_depth, source_lon, source_lat, 
                          station_lon, station_lat, wave_type='P', num_points=50):
        """
        Calculate realistic ray path using ray theory
        
        Parameters:
        -----------
        source_depth : float
            Earthquake depth in km
        source_lon, source_lat : float
            Source coordinates in degrees
        station_lon, station_lat : float
            Station coordinates in degrees
        wave_type : str
            'P' or 'S' wave
        num_points : int
            Number of points along ray path
            
        Returns:
        --------
        lon_points, lat_points, depth_points : arrays
            3D coordinates of ray path
        """
        
        # Select velocity model based on wave type
        velocities = self.vp_model if wave_type == 'P' else self.vs_model
        
        # Calculate epicentral distance
        epic_dist = self._calculate_distance(source_lon, source_lat, station_lon, station_lat)
        
        # Special case: very short distance (nearly vertical ray)
        if epic_dist < 5:  # Less than 5 km
            lon_points = np.linspace(source_lon, station_lon, num_points)
            lat_points = np.linspace(source_lat, station_lat, num_points)
            # Nearly straight path from source to surface
            depth_points = -np.linspace(source_depth, 0, num_points)
            return lon_points, lat_points, depth_points
        
        # Calculate ray parameter based on distance
        ray_param = self._calculate_ray_parameter(source_depth, epic_dist, velocities)
        
        # Trace ray path through velocity model
        ray_points = self._trace_ray(source_depth, epic_dist, ray_param, velocities, num_points)
        
        # Convert to 3D coordinates
        # Interpolate longitude and latitude along great circle path
        lon_points = np.linspace(source_lon, station_lon, num_points)
        lat_points = np.linspace(source_lat, station_lat, num_points)
        
        # Extract depths from ray tracing (negative for plotting convention)
        depths = -ray_points[:, 1]
        
        return lon_points, lat_points, depths
    
    def _calculate_distance(self, lon1, lat1, lon2, lat2):
        """Calculate great circle distance in km"""
        R = 6371.0  # Earth radius in km
        lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        return R * c
    
    def _calculate_ray_parameter(self, source_depth, distance, velocities):
        """
        Calculate ray parameter p for given source-receiver geometry
        Uses simplified approach based on distance
        """
        # Find velocity at source depth
        v_source = np.interp(source_depth, self.depth_layers, velocities)
        
        # Empirical relationship for ray parameter based on distance
        # This is simplified - real implementation would use ray shooting
        if distance < 50:
            # Direct wave - steep takeoff angle
            takeoff_angle = np.radians(70 - distance * 0.5)
        elif distance < 200:
            # Diving wave
            takeoff_angle = np.radians(50 - distance * 0.1)
        elif distance < 500:
            # Refracted wave in upper mantle
            takeoff_angle = np.radians(30 - distance * 0.02)
        else:
            # Deep refracted wave
            takeoff_angle = np.radians(20)
        
        # Ray parameter p = sin(takeoff_angle) / velocity
        ray_param = np.sin(takeoff_angle) / v_source
        
        return ray_param
    
    def _trace_ray(self, source_depth, distance, ray_param, velocities, num_points):
        """
        Trace ray path through 1D velocity model
        Returns array of (horizontal_distance, depth) points
        """
        ray_points = []
        
        # Determine maximum depth of ray penetration (turning point)
        turning_depth = self._calculate_turning_depth(ray_param, velocities, source_depth, distance)
        
        # Generate ray path based on distance range
        if distance < 100:  # Short distance - simple curved path
            # Direct wave with simple curvature
            for i in range(num_points):
                t = i / (num_points - 1)
                x = distance * t
                
                # Parabolic-like path
                if t < 0.5:
                    # Downgoing leg
                    z = source_depth + (turning_depth - source_depth) * (2 * t)
                else:
                    # Upgoing leg
                    z = turning_depth * (2 * (1 - t))
                
                ray_points.append([x, z])
                
        elif distance < 300:  # Medium distance - diving wave
            # More pronounced curvature
            half_dist = distance / 2
            
            for i in range(num_points):
                t = i / (num_points - 1)
                x = distance * t
                
                # Calculate depth along ray
                if x < half_dist:
                    # Downgoing leg - use sine for smooth curve
                    frac = x / half_dist
                    z = source_depth + (turning_depth - source_depth) * np.sin(frac * np.pi / 2)
                else:
                    # Upgoing leg
                    frac = (x - half_dist) / half_dist
                    z = turning_depth * np.cos(frac * np.pi / 2)
                
                ray_points.append([x, z])
                
        else:  # Long distance - refracted wave
            # Ray with head wave segment
            down_dist = distance * 0.25  # Distance for downgoing leg
            up_dist = distance * 0.25    # Distance for upgoing leg
            head_dist = distance * 0.5   # Distance along refractor
            
            for i in range(num_points):
                t = i / (num_points - 1)
                x = distance * t
                
                if x < down_dist:
                    # Downgoing leg
                    frac = x / down_dist
                    z = source_depth + (turning_depth - source_depth) * frac
                elif x < (distance - up_dist):
                    # Head wave (along layer)
                    z = turning_depth
                else:
                    # Upgoing leg
                    frac = (x - (distance - up_dist)) / up_dist
                    z = turning_depth * (1 - frac)
                
                ray_points.append([x, z])
        
        return np.array(ray_points)
    
    def _calculate_turning_depth(self, ray_param, velocities, source_depth, distance):
        """
        Calculate turning point depth for given ray parameter
        More realistic for local/regional earthquakes
        """
        # For local and regional earthquakes, rays don't go very deep
        # Typical crustal thickness is 30-40 km, upper mantle starts ~35 km
        
        if distance < 50:  # Very local
            # Direct wave through upper crust
            # Turning depth is just slightly below source
            turning_depth = source_depth + min(5, distance * 0.2)
            
        elif distance < 100:  # Local
            # Wave through lower crust
            # Maximum depth around 20-30 km
            turning_depth = source_depth + min(15, distance * 0.25)
            
        elif distance < 200:  # Near regional
            # Wave may reach Moho (~35 km)
            turning_depth = min(35, source_depth + distance * 0.2)
            
        elif distance < 400:  # Regional
            # Wave refracts along Moho or enters uppermost mantle
            # Maximum depth 40-60 km
            turning_depth = min(50, source_depth + 20 + distance * 0.05)
            
        else:  # Teleseismic
            # For very distant events, waves can go deeper
            # But still limited for typical local network
            turning_depth = min(100, source_depth + 30 + distance * 0.03)
        
        # Ensure turning depth is below source
        if turning_depth <= source_depth:
            turning_depth = source_depth + 2
        
        # For shallow earthquakes, limit maximum penetration
        if source_depth < 20:  # Shallow earthquake
            max_allowed_depth = 60  # Don't go too deep
            turning_depth = min(turning_depth, max_allowed_depth)
        
        return turning_depth


def plot_3d_ray_paths_separated(processor, config, 
                                output_file_p='seismic_3d_ray_paths_P.png', 
                                output_file_s='seismic_3d_ray_paths_S.png'):
    """
    Create separate 3D visualizations for P-waves and S-waves with realistic ray paths
    
    Parameters:
    -----------
    processor : SeismicDataProcessor
        Data processor object containing events, phases, and stations
    config : Config
        Configuration object with visualization parameters
    output_file_p : str
        Output filename for P-wave visualization
    output_file_s : str
        Output filename for S-wave visualization
    """
    
    print("Initializing realistic ray tracer...")
    ray_tracer = RealisticRayTracer()
    
    # Sample events for 3D visualization
    events_to_plot = processor.events
    if len(events_to_plot) > config.MAX_EVENTS_3D:
        import random
        random.seed(42)
        events_to_plot = random.sample(events_to_plot, config.MAX_EVENTS_3D)
        print(f"Sampled {config.MAX_EVENTS_3D} events from {len(processor.events)} total events")
    
    selected_event_ids = set(e['event_id'] for e in events_to_plot)
    
    # Separate phases by type
    p_phases = []
    s_phases = []
    
    for phase in processor.phases:
        if phase['event']['event_id'] in selected_event_ids:
            if phase['station'] in processor.stations:
                if phase['phase_type'] == 'P':
                    p_phases.append(phase)
                elif phase['phase_type'] == 'S':
                    s_phases.append(phase)
    
    print(f"Found {len(p_phases)} P-wave and {len(s_phases)} S-wave phases for selected events")
    
    # Sample stations for visualization
    stations_to_plot = list(processor.stations.items())
    if len(stations_to_plot) > config.MAX_STATIONS_3D:
        import random
        random.seed(42)
        stations_to_plot = random.sample(stations_to_plot, config.MAX_STATIONS_3D)
        print(f"Sampled {config.MAX_STATIONS_3D} stations from {len(processor.stations)} total stations")
    
    # ============= P-WAVE VISUALIZATION =============
    print("\nCreating P-wave 3D visualization...")
    fig_p = plt.figure(figsize=config.FIG_SIZE_3D)
    ax_p = fig_p.add_subplot(111, projection='3d')
    
    # Collect P-wave ray paths
    p_ray_segments = []
    p_ray_colors = []
    
    # Limit number of rays for performance
    max_rays = min(len(p_phases), 500000)
    if len(p_phases) > max_rays:
        import random
        random.seed(42)
        p_phases_plot = random.sample(p_phases, max_rays)
        print(f"Sampled {max_rays} P-wave rays for visualization")
    else:
        p_phases_plot = p_phases
    
    # Generate P-wave ray paths
    for i, phase in enumerate(p_phases_plot):
        if i % 100 == 0:
            print(f"  Processing P-wave ray {i}/{len(p_phases_plot)}...")
        
        station = processor.stations[phase['station']]
        event = phase['event']
        
        # Calculate realistic ray path
        try:
            lon_points, lat_points, depth_points = ray_tracer.calculate_ray_path(
                event['depth'], event['longitude'], event['latitude'],
                station['longitude'], station['latitude'], 
                wave_type='P', num_points=30
            )
            
            # Create line segments for 3D visualization
            points = np.array([lon_points, lat_points, depth_points]).T.reshape(-1, 1, 3)
            segments = np.concatenate([points[:-1], points[1:]], axis=1)
            
            p_ray_segments.extend(segments)
            p_ray_colors.extend([config.P_WAVE_COLOR_3D] * (len(points) - 1))
        except Exception as e:
            print(f"  Warning: Could not process ray path: {e}")
            continue
    
    # Add P-wave rays to plot
    if p_ray_segments:
        lc_p = Line3DCollection(p_ray_segments, colors=p_ray_colors, 
                               linewidths=0.4, alpha=0.6)
        ax_p.add_collection3d(lc_p)
        print(f"  Added {len(p_ray_segments)} P-wave ray segments to plot")
    
    # Plot earthquakes on P-wave plot
    for event in events_to_plot:
        size = 20 + event['magnitude'] * 10
        ax_p.scatter(event['longitude'], event['latitude'], -event['depth'],
                    c='red', s=size, marker='o', alpha=0.8,
                    edgecolors='darkred', linewidths=0.5)
    
    # Plot stations on P-wave plot
    for name, station in stations_to_plot:
        ax_p.scatter(station['longitude'], station['latitude'], 0,
                    c='gold', s=30, marker='^', alpha=0.9,
                    edgecolors='black', linewidths=0.5)
    
    # Add reference depth planes for P-wave plot
    xlim_p = ax_p.get_xlim()
    ylim_p = ax_p.get_ylim()
    xx_p, yy_p = np.meshgrid(np.linspace(xlim_p[0], xlim_p[1], 10),
                            np.linspace(ylim_p[0], ylim_p[1], 10))
    
    for depth in config.DEPTH_PLANES_3D:
        ax_p.plot_surface(xx_p, yy_p, np.ones_like(xx_p) * -depth,
                         alpha=0.02, color='blue', shade=False)
    
    # Formatting P-wave plot
    ax_p.set_xlabel('Longitude (°E)', fontsize=11, labelpad=10)
    ax_p.set_ylabel('Latitude (°N)', fontsize=11, labelpad=10)
    ax_p.set_zlabel('Depth (km)', fontsize=11, labelpad=10)
    ax_p.set_title('P-Wave Ray Paths (3D Visualization)', fontsize=14, fontweight='bold', pad=20)
    
    # Set viewing angle
    ax_p.view_init(elev=config.VIEW_ELEV_3D, azim=config.VIEW_AZIM_3D)
    
    # Grid and limits
    ax_p.grid(True, alpha=0.3)
    ax_p.set_zlim(-config.MAX_DEPTH_3D, 5)
    
    # Create P-wave legend
    legend_elements_p = [
        Line2D([0], [0], color=config.P_WAVE_COLOR_3D, lw=2, label='P-wave rays'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='r', 
               markersize=8, label='Earthquakes'),
        Line2D([0], [0], marker='^', color='w', markerfacecolor='gold', 
               markersize=8, label='Stations')
    ]
    ax_p.legend(handles=legend_elements_p, loc='upper right', frameon=True,
               fancybox=True, shadow=True, framealpha=0.9)
    
    # Add statistics text
    stats_text_p = f'P-waves: {len(p_phases_plot)} rays, {len(events_to_plot)} events, {len(stations_to_plot)} stations'
    ax_p.text2D(0.02, 0.02, stats_text_p, transform=ax_p.transAxes, fontsize=9,
               bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # Save P-wave visualization
    plt.tight_layout()
    plt.savefig(output_file_p, dpi=config.SAVE_DPI, bbox_inches='tight')
    plt.close()
    print(f"P-wave 3D visualization saved to {output_file_p}")
    
    # ============= S-WAVE VISUALIZATION =============
    print("\nCreating S-wave 3D visualization...")
    fig_s = plt.figure(figsize=config.FIG_SIZE_3D)
    ax_s = fig_s.add_subplot(111, projection='3d')
    
    # Collect S-wave ray paths
    s_ray_segments = []
    s_ray_colors = []
    
    # Limit number of rays for performance
    max_rays = min(len(s_phases), 500000)
    if len(s_phases) > max_rays:
        import random
        random.seed(42)
        s_phases_plot = random.sample(s_phases, max_rays)
        print(f"Sampled {max_rays} S-wave rays for visualization")
    else:
        s_phases_plot = s_phases
    
    # Generate S-wave ray paths
    for i, phase in enumerate(s_phases_plot):
        if i % 100 == 0:
            print(f"  Processing S-wave ray {i}/{len(s_phases_plot)}...")
        
        station = processor.stations[phase['station']]
        event = phase['event']
        
        # Calculate realistic ray path
        try:
            lon_points, lat_points, depth_points = ray_tracer.calculate_ray_path(
                event['depth'], event['longitude'], event['latitude'],
                station['longitude'], station['latitude'], 
                wave_type='S', num_points=30
            )
            
            # Create line segments for 3D visualization
            points = np.array([lon_points, lat_points, depth_points]).T.reshape(-1, 1, 3)
            segments = np.concatenate([points[:-1], points[1:]], axis=1)
            
            s_ray_segments.extend(segments)
            s_ray_colors.extend([config.S_WAVE_COLOR_3D] * (len(points) - 1))
        except Exception as e:
            print(f"  Warning: Could not process ray path: {e}")
            continue
    
    # Add S-wave rays to plot
    if s_ray_segments:
        lc_s = Line3DCollection(s_ray_segments, colors=s_ray_colors, 
                               linewidths=0.4, alpha=0.6)
        ax_s.add_collection3d(lc_s)
        print(f"  Added {len(s_ray_segments)} S-wave ray segments to plot")
    
    # Plot earthquakes on S-wave plot
    for event in events_to_plot:
        size = 20 + event['magnitude'] * 10
        ax_s.scatter(event['longitude'], event['latitude'], -event['depth'],
                    c='red', s=size, marker='o', alpha=0.8,
                    edgecolors='darkred', linewidths=0.5)
    
    # Plot stations on S-wave plot
    for name, station in stations_to_plot:
        ax_s.scatter(station['longitude'], station['latitude'], 0,
                    c='gold', s=30, marker='^', alpha=0.9,
                    edgecolors='black', linewidths=0.5)
    
    # Add reference depth planes for S-wave plot
    xlim_s = ax_s.get_xlim()
    ylim_s = ax_s.get_ylim()
    xx_s, yy_s = np.meshgrid(np.linspace(xlim_s[0], xlim_s[1], 10),
                            np.linspace(ylim_s[0], ylim_s[1], 10))
    
    for depth in config.DEPTH_PLANES_3D:
        ax_s.plot_surface(xx_s, yy_s, np.ones_like(xx_s) * -depth,
                         alpha=0.02, color='red', shade=False)
    
    # Formatting S-wave plot
    ax_s.set_xlabel('Longitude (°E)', fontsize=11, labelpad=10)
    ax_s.set_ylabel('Latitude (°N)', fontsize=11, labelpad=10)
    ax_s.set_zlabel('Depth (km)', fontsize=11, labelpad=10)
    ax_s.set_title('S-Wave Ray Paths (3D Visualization)', fontsize=14, fontweight='bold', pad=20)
    
    # Set viewing angle
    ax_s.view_init(elev=config.VIEW_ELEV_3D, azim=config.VIEW_AZIM_3D)
    
    # Grid and limits
    ax_s.grid(True, alpha=0.3)
    ax_s.set_zlim(-config.MAX_DEPTH_3D, 5)
    
    # Create S-wave legend
    legend_elements_s = [
        Line2D([0], [0], color=config.S_WAVE_COLOR_3D, lw=2, label='S-wave rays'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='r', 
               markersize=8, label='Earthquakes'),
        Line2D([0], [0], marker='^', color='w', markerfacecolor='gold', 
               markersize=8, label='Stations')
    ]
    ax_s.legend(handles=legend_elements_s, loc='upper right', frameon=True,
               fancybox=True, shadow=True, framealpha=0.9)
    
    # Add statistics text
    stats_text_s = f'S-waves: {len(s_phases_plot)} rays, {len(events_to_plot)} events, {len(stations_to_plot)} stations'
    ax_s.text2D(0.02, 0.02, stats_text_s, transform=ax_s.transAxes, fontsize=9,
               bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # Save S-wave visualization
    plt.tight_layout()
    plt.savefig(output_file_s, dpi=config.SAVE_DPI, bbox_inches='tight')
    plt.close()
    print(f"S-wave 3D visualization saved to {output_file_s}")
    
    print("\nCompleted 3D ray path visualizations!")
    print(f"Generated files:")
    print(f"  - {output_file_p}")
    print(f"  - {output_file_s}")


# Integration helper function
def integrate_with_main_program():
    """
    Example of how to integrate this enhanced 3D visualization
    with the existing seismic_visualization.py
    
    Add this to your main seismic_visualization.py file:
    """
    integration_code = '''
# In seismic_visualization.py, add this import at the top:
from enhanced_3d_ray_paths import plot_3d_ray_paths_separated

# Then in the SeismicPlotter class, replace the plot_3d_ray_paths method:
def plot_3d_ray_paths(self, output_file='3d_ray_paths.png'):
    """Enhanced 3D visualization with separated P and S waves"""
    # Call the new separated visualization function
    plot_3d_ray_paths_separated(
        self.processor, 
        self.config,
        output_file_p='seismic_3d_ray_paths_P.png',
        output_file_s='seismic_3d_ray_paths_S.png'
    )

# Or in the main() function, replace the 3D visualization section:
if config.ENABLE_3D_VISUALIZATION:
    print("\\nGenerating separated P-wave and S-wave 3D visualizations...")
    from enhanced_3d_ray_paths import plot_3d_ray_paths_separated
    plot_3d_ray_paths_separated(
        processor, 
        config,
        'seismic_3d_ray_paths_P.png',
        'seismic_3d_ray_paths_S.png'
    )
'''
    return integration_code


if __name__ == "__main__":
    """
    Standalone test - requires the Config and SeismicDataProcessor classes
    from the original seismic_visualization.py
    """
    print("Enhanced 3D Ray Path Visualization Module")
    print("==========================================")
    print("This module provides realistic 3D ray path visualization")
    print("with separate P-wave and S-wave plots.")
    print()
    print("To use this module:")
    print("1. Save this file as 'enhanced_3d_ray_paths.py'")
    print("2. Import the plot_3d_ray_paths_separated function in your main program")
    print("3. Call it with your processor and config objects")
    print()
    print("Integration example:")
    print(integrate_with_main_program())