#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Seismic Data Visualization Tool
Author: Seismic Analysis Team
Description: Generate publication-quality seismic ray path (2D/3D) and travel time plots
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.collections import LineCollection
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.spatial.distance import cdist
import pandas as pd
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Import 3D plotting tools
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Line3DCollection

# Import configuration
from config import Config

class SeismicDataProcessor:
    """Process seismic phase and station data"""
    
    def __init__(self, phase_file, station_file):
        self.phase_file = phase_file
        self.station_file = station_file
        self.events = []
        self.phases = []
        self.stations = {}
        
    def parse_phase_file(self):
        """Parse the seismic phase file"""
        with open(self.phase_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        current_event = None
        current_phases = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('#'):
                # Save previous event if exists
                if current_event and current_phases:
                    self.events.append(current_event)
                    self.phases.extend(current_phases)
                
                # Parse new event
                parts = line[1:].split()
                current_event = {
                    'year': int(parts[0]),
                    'month': int(parts[1]),
                    'day': int(parts[2]),
                    'hour': int(parts[3]),
                    'minute': int(parts[4]),
                    'second': float(parts[5]),
                    'latitude': float(parts[6]),
                    'longitude': float(parts[7]),
                    'depth': float(parts[8]),
                    'magnitude': float(parts[9]),
                    'event_id': int(parts[-1])
                }
                current_phases = []
            else:
                # Parse phase data
                parts = line.split()
                if len(parts) >= 4:
                    phase_data = {
                        'station': parts[0],
                        'arrival_time': float(parts[1]),
                        'residual': float(parts[2]),
                        'phase_type': parts[3],
                        'event': current_event
                    }
                    current_phases.append(phase_data)
        
        # Don't forget the last event
        if current_event and current_phases:
            self.events.append(current_event)
            self.phases.extend(current_phases)
    
    def parse_station_file(self):
        """Parse the station file"""
        with open(self.station_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 4:
                    self.stations[parts[0]] = {
                        'latitude': float(parts[1]),
                        'longitude': float(parts[2]),
                        'elevation': float(parts[3])
                    }
    
    def calculate_distances(self):
        """Calculate epicentral distances for all phases"""
        for phase in self.phases:
            if phase['station'] in self.stations:
                station = self.stations[phase['station']]
                event = phase['event']
                
                # Calculate great circle distance
                lat1, lon1 = np.radians(event['latitude']), np.radians(event['longitude'])
                lat2, lon2 = np.radians(station['latitude']), np.radians(station['longitude'])
                
                dlat = lat2 - lat1
                dlon = lon2 - lon1
                
                a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
                c = 2 * np.arcsin(np.sqrt(a))
                distance = 6371.0 * c  # Earth radius in km
                
                # Calculate hypocenter distance
                depth = event['depth']
                hypo_distance = np.sqrt(distance**2 + depth**2)
                
                phase['epicentral_distance'] = distance
                phase['hypocenter_distance'] = hypo_distance

class SeismicPlotter:
    """Create publication-quality seismic plots"""
    
    def __init__(self, processor, config):
        self.processor = processor
        self.config = config
        self.setup_style()
    
    def setup_style(self):
        """Set up matplotlib style for Nature-quality figures"""
        plt.rcParams.update({
            'font.family': 'Arial',
            'font.size': 10,
            'axes.linewidth': 1.2,
            'axes.labelsize': 11,
            'axes.titlesize': 12,
            'xtick.labelsize': 10,
            'ytick.labelsize': 10,
            'legend.fontsize': 9,
            'figure.dpi': 300,
            'savefig.dpi': 300,
            'savefig.bbox': 'tight',
            'savefig.pad_inches': 0.1
        })
    
    def plot_3d_ray_paths(self, output_file='3d_ray_paths.png'):
        """Create 3D visualization of seismic ray paths"""
        fig = plt.figure(figsize=self.config.FIG_SIZE_3D)
        ax = fig.add_subplot(111, projection='3d')
        
        # Sample events for 3D visualization
        events_to_plot = self.processor.events
        if len(events_to_plot) > self.config.MAX_EVENTS_3D:
            import random
            random.seed(42)
            events_to_plot = random.sample(events_to_plot, self.config.MAX_EVENTS_3D)
        
        selected_event_ids = set(e['event_id'] for e in events_to_plot)
        
        print(f"Creating 3D visualization with {len(events_to_plot)} events...")
        
        # Collect ray paths
        ray_segments = []
        ray_colors = []
        ray_depths = []
        
        for phase in self.processor.phases:
            if phase['event']['event_id'] in selected_event_ids:
                if phase['station'] in self.processor.stations:
                    station = self.processor.stations[phase['station']]
                    event = phase['event']
                    
                    # Create 3D ray path with curved trajectory
                    n_points = self.config.RAY_POINTS_3D  # Points along ray path
                    
                    # Start point (earthquake hypocenter)
                    x1, y1, z1 = event['longitude'], event['latitude'], -event['depth']
                    
                    # End point (station at surface)
                    x2, y2, z2 = station['longitude'], station['latitude'], 0
                    
                    # Create curved ray path (simulate wave propagation)
                    t = np.linspace(0, 1, n_points)
                    
                    # Interpolate position
                    x = x1 + (x2 - x1) * t
                    y = y1 + (y2 - y1) * t
                    
                    # Create curved depth profile (rays travel deeper before returning)
                    max_depth = -event['depth'] * 1.5  # Maximum depth of ray
                    z = z1 + (z2 - z1) * t + max_depth * np.sin(np.pi * t) * self.config.RAY_CURVATURE_3D
                    
                    # Create line segments
                    points = np.array([x, y, z]).T.reshape(-1, 1, 3)
                    segments = np.concatenate([points[:-1], points[1:]], axis=1)
                    
                    ray_segments.extend(segments)
                    
                    # Color by phase type
                    if phase['phase_type'] == 'P':
                        ray_colors.extend([self.config.P_WAVE_COLOR_3D] * (n_points - 1))
                    else:
                        ray_colors.extend([self.config.S_WAVE_COLOR_3D] * (n_points - 1))
                    
                    ray_depths.extend(z[:-1])
        
        # Plot ray paths
        if ray_segments:
            lc = Line3DCollection(ray_segments, colors=ray_colors, 
                                 linewidths=0.5, alpha=0.4)
            ax.add_collection3d(lc)
            print(f"Added {len(ray_segments)} ray segments to 3D plot")
        
        # Plot earthquakes
        for event in events_to_plot:
            size = 20 + event['magnitude'] * 10
            ax.scatter(event['longitude'], event['latitude'], -event['depth'],
                      c='red', s=size, marker='o', alpha=0.8,
                      edgecolors='darkred', linewidths=0.5)
        
        # Plot stations
        stations_to_plot = list(self.processor.stations.items())
        if len(stations_to_plot) > self.config.MAX_STATIONS_3D:
            import random
            random.seed(42)
            stations_to_plot = random.sample(stations_to_plot, self.config.MAX_STATIONS_3D)
        
        for name, station in stations_to_plot:
            ax.scatter(station['longitude'], station['latitude'], 0,
                      c='gold', s=30, marker='^', alpha=0.9,
                      edgecolors='black', linewidths=0.5)
        
        print(f"Plotted {len(events_to_plot)} events and {len(stations_to_plot)} stations")
        
        # Add depth planes for reference
        # Get axis limits
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        
        xx, yy = np.meshgrid(
            np.linspace(xlim[0], xlim[1], 10),
            np.linspace(ylim[0], ylim[1], 10)
        )
        
        for depth in self.config.DEPTH_PLANES_3D:
            ax.plot_surface(xx, yy, np.ones_like(xx) * -depth,
                          alpha=0.05, color='gray', shade=False)
        
        # Formatting
        ax.set_xlabel('Longitude (°E)', fontsize=11, labelpad=10)
        ax.set_ylabel('Latitude (°N)', fontsize=11, labelpad=10)
        ax.set_zlabel('Depth (km)', fontsize=11, labelpad=10)
#        ax.set_title('3D Seismic Ray Path Visualization', fontsize=14, fontweight='bold', pad=20)
        
        # Set viewing angle
        ax.view_init(elev=self.config.VIEW_ELEV_3D, azim=self.config.VIEW_AZIM_3D)
        
        # Add grid
        ax.grid(True, alpha=0.3)
        
        # Adjust limits
        ax.set_zlim(-self.config.MAX_DEPTH_3D, 5)
        
        # Add legend
        from matplotlib.lines import Line2D
        legend_elements = [
            Line2D([0], [0], color=self.config.P_WAVE_COLOR_3D, lw=2, label='P-wave rays'),
            Line2D([0], [0], color=self.config.S_WAVE_COLOR_3D, lw=2, label='S-wave rays'),
            Line2D([0], [0], marker='o', color='w', markerfacecolor='r', markersize=8, label='Earthquakes'),
            Line2D([0], [0], marker='^', color='w', markerfacecolor='gold', markersize=8, label='Stations')
        ]
        ax.legend(handles=legend_elements, loc='upper right')
        
        # Add statistics text
        stats_text = f'Total: {len(events_to_plot)} events, {len(stations_to_plot)} stations, {len(ray_segments)} ray segments'
        ax.text2D(0.02, 0.02, stats_text, transform=ax.transAxes, fontsize=9, 
                 bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"3D ray path visualization saved to {output_file}")
    
    def plot_ray_paths(self, output_file='ray_paths.png'):
        """Create ray path map with topography"""
        fig = plt.figure(figsize=(12, 10))
        
        # Use all events or sample if too many
        events_to_plot = self.processor.events
        print(f"Total events in dataset: {len(self.processor.events)}")
        
        if len(events_to_plot) > self.config.MAX_EVENTS_TO_PLOT:
            import random
            random.seed(42)  # For reproducibility
            events_to_plot = random.sample(events_to_plot, self.config.MAX_EVENTS_TO_PLOT)
            print(f"Sampling {self.config.MAX_EVENTS_TO_PLOT} events for visualization")
        else:
            print(f"Using all {len(events_to_plot)} events")
        
        # Get event IDs for selected events
        selected_event_ids = set(e['event_id'] for e in events_to_plot)
        
        # Determine extents
        all_lons = []
        all_lats = []
        
        # Collect all coordinates from events
        for event in events_to_plot:
            all_lons.append(event['longitude'])
            all_lats.append(event['latitude'])
        
        # Collect all coordinates from stations
        for station in self.processor.stations.values():
            all_lons.append(station['longitude'])
            all_lats.append(station['latitude'])
        
        print(f"Data extent - Lon: [{min(all_lons):.2f}, {max(all_lons):.2f}], Lat: [{min(all_lats):.2f}, {max(all_lats):.2f}]")
        
        # Main map extent (automatic from all data)
        main_lon_min = min(all_lons) - self.config.MAIN_MAP_PADDING
        main_lon_max = max(all_lons) + self.config.MAIN_MAP_PADDING
        main_lat_min = min(all_lats) - self.config.MAIN_MAP_PADDING
        main_lat_max = max(all_lats) + self.config.MAIN_MAP_PADDING
        
        print(f"Main map extent - Lon: [{main_lon_min:.2f}, {main_lon_max:.2f}], Lat: [{main_lat_min:.2f}, {main_lat_max:.2f}]")
        
        # Study area extent (for detailed inset)
        if self.config.AUTO_EXTENT:
            study_lon_min = min(all_lons) - 0.5
            study_lon_max = max(all_lons) + 0.5
            study_lat_min = min(all_lats) - 0.5
            study_lat_max = max(all_lats) + 0.5
        else:
            study_lon_min = self.config.MAP_LON_MIN
            study_lon_max = self.config.MAP_LON_MAX
            study_lat_min = self.config.MAP_LAT_MIN
            study_lat_max = self.config.MAP_LAT_MAX
        
        # ============ MAIN MAP - Shows ALL data with ray paths (like inset but for all data) ============
        ax_main = fig.add_subplot(111, projection=ccrs.PlateCarree())
        ax_main.set_extent([main_lon_min, main_lon_max, main_lat_min, main_lat_max], ccrs.PlateCarree())
        
        # Add background features (simple, like Figure 1)
        ax_main.add_feature(cfeature.LAND, facecolor='#ffffff', alpha=1.0, edgecolor='none')
        ax_main.add_feature(cfeature.OCEAN, facecolor='#f0f0f0', alpha=1.0)
        ax_main.add_feature(cfeature.COASTLINE, linewidth=0.8, color='#666666')
        ax_main.add_feature(cfeature.BORDERS, linewidth=0.5, color='#999999', alpha=0.5)
        
        # First, plot ALL stations on main map
        stations_to_plot_main = list(self.processor.stations.items())
        if len(stations_to_plot_main) > self.config.MAX_STATIONS_TO_PLOT:
            import random
            random.seed(42)
            stations_to_plot_main = random.sample(stations_to_plot_main, self.config.MAX_STATIONS_TO_PLOT)
            print(f"Sampling {self.config.MAX_STATIONS_TO_PLOT} stations for main map")
        else:
            print(f"Plotting all {len(stations_to_plot_main)} stations")
        
        for i, (name, station) in enumerate(stations_to_plot_main):
            ax_main.scatter(station['longitude'], station['latitude'],
                          s=self.config.STATION_SIZE, c=self.config.STATION_COLOR, 
                          marker=self.config.STATION_MARKER,
                          edgecolors='black', linewidths=0.5,
                          transform=ccrs.PlateCarree(),
                          zorder=4, alpha=0.9,
                          label='Station' if i == 0 else '')
        
        # Plot ALL ray paths on main map (same method as inset but for all data)
        ray_lines_main = []
        
        # Get ALL phases for selected events
        phases_for_main = []
        for phase in self.processor.phases:
            if phase['event']['event_id'] in selected_event_ids:
                if phase['station'] in self.processor.stations:
                    phases_for_main.append(phase)
        
        print(f"Total phases available for main map: {len(phases_for_main)}")
        
        # Create ray lines for all phases
        for phase in phases_for_main:
            station = self.processor.stations[phase['station']]
            event = phase['event']
            
            lon1, lat1 = event['longitude'], event['latitude']
            lon2, lat2 = station['longitude'], station['latitude']
            ray_lines_main.append([(lon1, lat1), (lon2, lat2)])
        
        print(f"Total ray lines created for main map: {len(ray_lines_main)}")
        
        # Sample if too many rays
        if len(ray_lines_main) > self.config.MAX_RAYS_TO_PLOT:
            import random
            random.seed(42)
            ray_lines_main = random.sample(ray_lines_main, self.config.MAX_RAYS_TO_PLOT)
            print(f"Sampled to {self.config.MAX_RAYS_TO_PLOT} ray paths")
        
        # Add ray paths to main map
        if ray_lines_main:
            lc_main = LineCollection(ray_lines_main, 
                                    colors=self.config.RAY_COLOR,
                                    linewidths=self.config.RAY_WIDTH,
                                    alpha=self.config.RAY_ALPHA,
                                    transform=ccrs.PlateCarree(),
                                    zorder=2)
            ax_main.add_collection(lc_main)
            print(f"Added {len(ray_lines_main)} ray paths to main map")
        else:
            print("WARNING: No ray paths to plot on main map!")
        
        # Plot ALL events on main map (red circles) - AFTER rays
        for event in events_to_plot:
            size = self.config.EVENT_SIZE_BASE + event['magnitude'] * self.config.EVENT_SIZE_SCALE
            ax_main.scatter(event['longitude'], event['latitude'],
                          s=size, c=self.config.EVENT_COLOR, marker='o',
                          edgecolors='darkred', linewidths=0.5,
                          transform=ccrs.PlateCarree(),
                          zorder=5, alpha=0.9,
                          label='Earthquake' if event == events_to_plot[0] else '')
        
        # Add gridlines to main map
        gl = ax_main.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.3)
        gl.top_labels = False
        gl.right_labels = False
        
        # Add scale bar and north arrow to main map
        self._add_scale_bar(ax_main, main_lon_min, main_lat_min, main_lat_max)
        self._add_north_arrow(ax_main, main_lon_max, main_lat_max)
        
        # Add legend to MAIN map with ray path (改为左上角)
        handles, labels = ax_main.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        
        # Add ray path line to legend
        import matplotlib.lines as mlines
        ray_line = mlines.Line2D([], [], color=self.config.RAY_COLOR, 
                                linewidth=2, alpha=self.config.RAY_ALPHA, label='Ray path')
        by_label['Ray path'] = ray_line
        
        # Create legend with all three elements (修改位置为左上角)
        ax_main.legend(by_label.values(), by_label.keys(),
                      loc='upper left', frameon=True, fancybox=True,
                      shadow=True, framealpha=0.9)
        
        # Title for main map
#        title = f'Seismic Ray Path Distribution\n({len(events_to_plot)} events, {len(ray_lines_main)} rays)'
#        ax_main.set_title(title, fontsize=14, fontweight='bold', pad=20)
        
        # Add rectangle showing study area on main map
        rect_main = patches.Rectangle((study_lon_min, study_lat_min), 
                                      study_lon_max-study_lon_min, 
                                      study_lat_max-study_lat_min,
                                      linewidth=2, edgecolor='red', facecolor='none',
                                      transform=ccrs.PlateCarree(), zorder=10)
        ax_main.add_patch(rect_main)
        
        # ============ INSET MAP - Shows detailed study area (same drawing method) ============
        ax_inset = fig.add_axes(self.config.INSET_POSITION, projection=ccrs.PlateCarree())
        ax_inset.set_extent([study_lon_min, study_lon_max, study_lat_min, study_lat_max], 
                           ccrs.PlateCarree())
        
        # Add features to inset (enhanced contrast for ocean)
        ax_inset.add_feature(cfeature.LAND, facecolor='#ffffff', alpha=1.0, edgecolor='none')
        ax_inset.add_feature(cfeature.OCEAN, facecolor='#4682B4', alpha=0.9)  # Blue ocean for contrast
        ax_inset.add_feature(cfeature.COASTLINE, linewidth=0.8, color='black')
        ax_inset.add_feature(cfeature.BORDERS, linewidth=0.5, color='gray', alpha=0.5)
        
        # Plot stations in INSET first
        stations_in_study = [(name, station) for name, station in self.processor.stations.items()
                            if study_lon_min <= station['longitude'] <= study_lon_max and
                               study_lat_min <= station['latitude'] <= study_lat_max]
        
        for name, station in stations_in_study:
            ax_inset.scatter(station['longitude'], station['latitude'],
                           s=self.config.STATION_SIZE * 0.7, 
                           c=self.config.STATION_COLOR, 
                           marker=self.config.STATION_MARKER,
                           edgecolors='black', linewidths=0.5,
                           transform=ccrs.PlateCarree(),
                           zorder=4, alpha=0.9)
        
        # Plot ray paths in INSET (only for study area events)
        ray_lines_inset = []
        events_in_study = [e for e in events_to_plot if 
                          study_lon_min <= e['longitude'] <= study_lon_max and
                          study_lat_min <= e['latitude'] <= study_lat_max]
        
        study_event_ids = set(e['event_id'] for e in events_in_study)
        
        # Get phases for events in study area
        for phase in self.processor.phases:
            if phase['event']['event_id'] in study_event_ids:
                if phase['station'] in self.processor.stations:
                    station = self.processor.stations[phase['station']]
                    event = phase['event']
                    
                    # Include rays that connect to stations within or near study area
                    if (study_lon_min - 2 <= station['longitude'] <= study_lon_max + 2 and
                        study_lat_min - 2 <= station['latitude'] <= study_lat_max + 2):
                        
                        lon1, lat1 = event['longitude'], event['latitude']
                        lon2, lat2 = station['longitude'], station['latitude']
                        ray_lines_inset.append([(lon1, lat1), (lon2, lat2)])
        
        # Add ray paths to inset
        if ray_lines_inset:
            lc_inset = LineCollection(ray_lines_inset, 
                                     colors=self.config.RAY_COLOR,
                                     linewidths=self.config.RAY_WIDTH * 0.8,
                                     alpha=self.config.RAY_ALPHA * 1.2,
                                     transform=ccrs.PlateCarree(),
                                     zorder=2)
            ax_inset.add_collection(lc_inset)
        
        # Plot events in INSET (red circles) - AFTER rays
        for event in events_in_study:
            size = (self.config.EVENT_SIZE_BASE + event['magnitude'] * self.config.EVENT_SIZE_SCALE) * 0.7
            ax_inset.scatter(event['longitude'], event['latitude'],
                           s=size, c=self.config.EVENT_COLOR, marker='o',
                           edgecolors='darkred', linewidths=0.5,
                           transform=ccrs.PlateCarree(),
                           zorder=5, alpha=0.9)
        
        # Add gridlines to inset
        gl_inset = ax_inset.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.3)
        
        # Add frame to inset
        ax_inset.spines['geo'].set_edgecolor('black')
        ax_inset.spines['geo'].set_linewidth(1.5)
        
        # Add title to inset
        inset_title = 'Study Area'
        ax_inset.text(0.5, 1.02, inset_title, transform=ax_inset.transAxes,
                     fontsize=11, fontweight='bold', ha='center', va='bottom')
        
        # Add statistics below the inset title
        stats_text = f'({len(events_in_study)} events, {len(ray_lines_inset)} rays)'
        ax_inset.text(0.5, 0.98, stats_text, transform=ax_inset.transAxes,
                     fontsize=9, ha='center', va='top')
        
        # Add labels to inset
        if events_in_study:
            avg_mag = sum(e['magnitude'] for e in events_in_study) / len(events_in_study)
            ax_inset.text(0.95, 0.95, f'M={avg_mag:.1f}',
                         transform=ax_inset.transAxes, fontsize=9, ha='right', va='top',
                         bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
        
        # Add coordinate labels around inset frame
        ax_inset.text(0.5, -0.05, f'{study_lon_min:.1f}°E - {study_lon_max:.1f}°E',
                     transform=ax_inset.transAxes, fontsize=8, ha='center', va='top')
        ax_inset.text(-0.08, 0.5, f'{study_lat_min:.1f}°N - {study_lat_max:.1f}°N',
                     transform=ax_inset.transAxes, fontsize=8, ha='center', va='center',
                     rotation=90)
        
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Ray path map saved to {output_file}")
    
    def plot_travel_times(self, output_file='travel_times.png'):
        """Create travel time vs distance plot"""
        fig, ax = plt.subplots(figsize=(10, 7))
        
        # Separate P and S phases
        p_distances = []
        p_times = []
        s_distances = []
        s_times = []
        
        # Apply filtering if configured
        for phase in self.processor.phases:
            if 'hypocenter_distance' in phase:
                # Check if data should be filtered
                if not self.config.AUTO_LIMITS_DISTANCE and self.config.FILTER_OUTSIDE_LIMITS:
                    if phase['hypocenter_distance'] < self.config.DISTANCE_MIN or \
                       phase['hypocenter_distance'] > self.config.DISTANCE_MAX:
                        continue
                
                if not self.config.AUTO_LIMITS_TIME and self.config.FILTER_OUTSIDE_LIMITS:
                    if phase['arrival_time'] < self.config.TIME_MIN or \
                       phase['arrival_time'] > self.config.TIME_MAX:
                        continue
                
                if phase['phase_type'] == 'P':
                    p_distances.append(phase['hypocenter_distance'])
                    p_times.append(phase['arrival_time'])
                elif phase['phase_type'] == 'S':
                    s_distances.append(phase['hypocenter_distance'])
                    s_times.append(phase['arrival_time'])
        
        # Sample data if too many points for better visualization
        max_points = 5000
        if len(p_distances) > max_points:
            import random
            indices = random.sample(range(len(p_distances)), max_points)
            p_distances = [p_distances[i] for i in indices]
            p_times = [p_times[i] for i in indices]
            print(f"Sampled {max_points} P-wave data points for visualization")
        
        if len(s_distances) > max_points:
            import random
            indices = random.sample(range(len(s_distances)), max_points)
            s_distances = [s_distances[i] for i in indices]
            s_times = [s_times[i] for i in indices]
            print(f"Sampled {max_points} S-wave data points for visualization")
        
        # Plot data points with smaller size for large datasets
        point_size = self.config.MARKER_SIZE if len(p_distances) < 1000 else 5
        
        ax.scatter(p_distances, p_times, c=self.config.P_WAVE_COLOR,
                  s=point_size, alpha=self.config.MARKER_ALPHA,
                  label='P-wave', edgecolors='none', rasterized=True)
        ax.scatter(s_distances, s_times, c=self.config.S_WAVE_COLOR,
                  s=point_size, alpha=self.config.MARKER_ALPHA,
                  label='S-wave', edgecolors='none', rasterized=True)
        
        # Fit and plot trend lines
        vp, vs = None, None
        if len(p_distances) > 10:
            z_p = np.polyfit(p_distances, p_times, 1)
            p_p = np.poly1d(z_p)
            vp = 1.0 / z_p[0]  # km/s
            
            # Plot trend line within the configured range
            if self.config.AUTO_LIMITS_DISTANCE:
                x_start, x_end = 0, max(p_distances)
            else:
                x_start = self.config.DISTANCE_MIN
                x_end = self.config.DISTANCE_MAX
            
            x_smooth = np.linspace(x_start, x_end, 100)
            ax.plot(x_smooth, p_p(x_smooth), self.config.P_WAVE_COLOR,
                   linewidth=2, alpha=0.8, linestyle='-', 
                   label=f'P-wave fit (Vp={vp:.2f} km/s)')
        
        if len(s_distances) > 10:
            z_s = np.polyfit(s_distances, s_times, 1)
            p_s = np.poly1d(z_s)
            vs = 1.0 / z_s[0]  # km/s
            
            # Plot trend line within the configured range
            if self.config.AUTO_LIMITS_DISTANCE:
                x_start, x_end = 0, max(s_distances)
            else:
                x_start = self.config.DISTANCE_MIN
                x_end = self.config.DISTANCE_MAX
            
            x_smooth = np.linspace(x_start, x_end, 100)
            ax.plot(x_smooth, p_s(x_smooth), self.config.S_WAVE_COLOR,
                   linewidth=2, alpha=0.8, linestyle='-', 
                   label=f'S-wave fit (Vs={vs:.2f} km/s)')
        
        # Formatting
        ax.set_xlabel('Hypocenter Distance (km)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Travel Time (s)', fontsize=12, fontweight='bold')
        
        # Add data count to title
#        title = f'Seismic Wave Travel Time Analysis\n'
#        title += f'(P: {len(p_distances)} points, S: {len(s_distances)} points)'
#        ax.set_title(title, fontsize=14, fontweight='bold', pad=15)
        
        # Grid
        ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
        ax.set_axisbelow(True)
        
        # Legend
        ax.legend(loc='upper left', frameon=True, fancybox=True, shadow=True, framealpha=0.9)
        
        # Set X-axis limits (distance)
        if self.config.AUTO_LIMITS_DISTANCE:
            if p_distances or s_distances:
                max_dist = max(p_distances + s_distances) if (p_distances + s_distances) else 300
                ax.set_xlim(0, max_dist * 1.05)
            else:
                ax.set_xlim(0, 300)
        else:
            ax.set_xlim(self.config.DISTANCE_MIN, self.config.DISTANCE_MAX)
        
        # Set Y-axis limits (time)
        if self.config.AUTO_LIMITS_TIME:
            if p_times or s_times:
                max_time = max(p_times + s_times) if (p_times + s_times) else 100
                ax.set_ylim(0, max_time * 1.05)
            else:
                ax.set_ylim(0, 100)
        else:
            ax.set_ylim(self.config.TIME_MIN, self.config.TIME_MAX)
        
        # Add Vp/Vs ratio if both velocities are available
        if vp and vs:
            vp_vs_ratio = vp / vs
            ax.text(0.95, 0.05, f'Vp/Vs = {vp_vs_ratio:.2f}',
                   transform=ax.transAxes, fontsize=10,
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.8),
                   ha='right', va='bottom')
        
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Travel time plot saved to {output_file}")
    
    def _add_scale_bar(self, ax, lon_min, lat_min, lat_max):
        """Add a scale bar to the map"""
        # Calculate scale
        lat_center = (lat_min + lat_max) / 2
        km_per_degree = 111.0 * np.cos(np.radians(lat_center))
        scale_km = 50  # 50 km scale bar
        scale_degrees = scale_km / km_per_degree
        
        # Position
        x_pos = lon_min + 0.1
        y_pos = lat_min + 0.1
        
        # Draw scale bar
        ax.plot([x_pos, x_pos + scale_degrees], [y_pos, y_pos],
               'k-', linewidth=3, transform=ccrs.PlateCarree())
        ax.text(x_pos + scale_degrees/2, y_pos + 0.05, f'{scale_km} km',
               ha='center', va='bottom', fontsize=9,
               transform=ccrs.PlateCarree())
    
    def _add_north_arrow(self, ax, lon_max, lat_max):
        """Add a north arrow to the map"""
        x_pos = lon_max - 0.3
        y_pos = lat_max - 0.3
        
        ax.annotate('N', xy=(x_pos, y_pos), xytext=(x_pos, y_pos - 0.2),
                   arrowprops=dict(arrowstyle='->', lw=2, color='black'),
                   ha='center', va='center', fontsize=12, fontweight='bold',
                   transform=ccrs.PlateCarree())

def main():
    """Main execution function"""
    # Initialize configuration
    config = Config()
    
    # Print configuration summary
    config.print_config()
    
    # Check if input files exist
    if not Path(config.PHASE_FILE).exists():
        print(f"Error: Phase file '{config.PHASE_FILE}' not found!")
        return
    
    if not Path(config.STATION_FILE).exists():
        print(f"Error: Station file '{config.STATION_FILE}' not found!")
        return
    
    # Process data
    print("\nProcessing seismic data...")
    processor = SeismicDataProcessor(config.PHASE_FILE, config.STATION_FILE)
    processor.parse_phase_file()
    processor.parse_station_file()
    processor.calculate_distances()
    
    print(f"Loaded {len(processor.events)} events and {len(processor.stations)} stations")
    print(f"Total phases: {len(processor.phases)}")
    
    # Create plots
    plotter = SeismicPlotter(processor, config)
    
    print("\nGenerating ray path map...")
    plotter.plot_ray_paths(config.OUTPUT_RAY_PATH)
    
    # Generate 3D visualization if enabled
    if config.ENABLE_3D_VISUALIZATION:
        print("\nGenerating 3D ray path visualization...")
        plotter.plot_3d_ray_paths(config.OUTPUT_3D_RAY_PATH)
    
    print("\nGenerating travel time plot...")
    plotter.plot_travel_times(config.OUTPUT_TRAVEL_TIME)
    
    print("\nVisualization complete!")
    print(f"Output files:")
    print(f"  - {config.OUTPUT_RAY_PATH}")
    if config.ENABLE_3D_VISUALIZATION:
        print(f"  - {config.OUTPUT_3D_RAY_PATH}")
    print(f"  - {config.OUTPUT_TRAVEL_TIME}")

if __name__ == "__main__":
    main()