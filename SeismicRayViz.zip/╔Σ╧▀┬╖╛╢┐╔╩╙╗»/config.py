#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Configuration file for Seismic Data Visualization
Adjust these parameters to customize the visualization

=== LAYOUT DESCRIPTION ===
Main Map (Bottom): Shows ALL data with ray paths
Inset Map (Top-Right): Shows detailed view of the study area with denser ray paths
3D Visualization: Shows ray paths in 3D space with curved trajectories

=== QUICK START GUIDE ===
1. Set MAP_LON_MIN, MAP_LON_MAX, MAP_LAT_MIN, MAP_LAT_MAX to define your STUDY AREA
   (This area will be shown in detail in the inset map)
2. Set AUTO_EXTENT = False to use your defined study area
3. Adjust MAIN_MAP_PADDING to control how much area around data to show in main map
4. Modify MAX_EVENTS_TO_PLOT, MAX_RAYS_TO_PLOT for performance optimization
5. Configure 3D visualization settings (VIEW_ELEV_3D, VIEW_AZIM_3D, etc.)
"""

class Config:
    """Configuration parameters for seismic visualization"""
    
    # ==================== Input Files ====================
    # Path to the seismic phase file
    PHASE_FILE = "paste.txt"
    
    # Path to the station file  
    STATION_FILE = "paste-2.txt"
    
    # ==================== Output Files ====================
    # Output ray path map filename
    OUTPUT_RAY_PATH = "seismic_ray_paths.png"
    
    # Output travel time plot filename
    OUTPUT_TRAVEL_TIME = "seismic_travel_times.png"
    
    # Output 3D ray path visualization
    OUTPUT_3D_RAY_PATH = "seismic_3d_ray_paths.png"
    
    # ==================== 3D Visualization Settings ====================
    # Enable 3D visualization
    ENABLE_3D_VISUALIZATION = True
    
    # Maximum number of events for 3D visualization
    MAX_EVENTS_3D = 50000  # Limit for performance
    
    # Maximum number of stations for 3D visualization
    MAX_STATIONS_3D = 800
    
    # 3D view angles
    VIEW_ELEV_3D = 20  # Elevation angle (degrees)
    VIEW_AZIM_3D = -60  # Azimuth angle (degrees)
    
    # Maximum depth for 3D visualization (km)
    MAX_DEPTH_3D = 30
    
    # Depth planes to show as reference (km)
    DEPTH_PLANES_3D = [5, 10, 20, 30]
    
    # Colors for 3D ray paths
    P_WAVE_COLOR_3D = "#0080FF"  # Bright blue for P-waves
    S_WAVE_COLOR_3D = "#FF4500"  # Orange-red for S-waves
    
    # 3D figure size
    FIG_SIZE_3D = (14, 10)
    
    # Ray path curvature for 3D (0-1, higher = more curved)
    RAY_CURVATURE_3D = 0.3
    
    # Number of points along each 3D ray path
    RAY_POINTS_3D = 20
    
    # ==================== Ray Path Map Settings ====================
    # Ray path visualization
    RAY_COLOR = "#0066FF"  # Blue color for ray paths (matching Figure 1)
    RAY_WIDTH = 1.0  # Line width for ray paths (increased for better visibility)
    RAY_ALPHA = 0.7  # Transparency of ray paths (increased for better visibility)
    
    # Event (earthquake) markers
    EVENT_COLOR = "#FF0000"  # Pure red color for events
    EVENT_MARKER = "o"  # Circle marker for events
    EVENT_SIZE_BASE = 30  # Base size for event markers
    EVENT_SIZE_SCALE = 10  # Scale factor for magnitude
    
    # Station markers
    STATION_COLOR = "#FFD700"  # Gold/yellow color for stations
    STATION_MARKER = "^"  # Triangle marker for stations
    STATION_SIZE = 60  # Size of station markers
    
    # Inset map settings
    # Position: [left, bottom, width, height] in figure coordinates (0-1)
    # The inset shows the DETAILED study area with denser ray paths
    INSET_POSITION = [0.60, 0.60, 0.35, 0.35]  # Upper right corner position
    INSET_PADDING = 5  # Not used in new layout (kept for compatibility)
    
    # Legend position for ray path map (in the inset)
    # Options: 'upper left', 'upper right', 'lower left', 'lower right', 'best'
    LEGEND_POSITION = 'upper left'  # Position within the inset map
    
    # Map extent padding (degrees)
    MAP_PADDING = 0.5
    
    # ==================== Map Extent Settings ====================
    # Define the STUDY AREA extent (will be shown in the inset with ray paths)
    # These coordinates define your research area
    MAP_LON_MIN = 116.5  # Minimum longitude for study area
    MAP_LON_MAX = 119.5  # Maximum longitude for study area  
    MAP_LAT_MIN = 38.5   # Minimum latitude for study area
    MAP_LAT_MAX = 40.5   # Maximum latitude for study area
    
    # If AUTO_EXTENT is True, ignore above settings and calculate from data
    AUTO_EXTENT = False
    
    # Main map padding (degrees) - for the broader view
    MAIN_MAP_PADDING = 1.0  # Reduced to show data more closely
    
    # Map extent padding when AUTO_EXTENT is True (degrees)
    MAP_PADDING = 0.5
    
    # ==================== Travel Time Plot Settings ====================
    # P-wave settings
    P_WAVE_COLOR = "#0066CC"  # Blue color for P-waves
    P_WAVE_MARKER = "o"  # Circle marker for P-waves
    
    # S-wave settings
    S_WAVE_COLOR = "#CC0000"  # Red color for S-waves
    S_WAVE_MARKER = "o"  # Circle marker for S-waves
    
    # Marker settings
    MARKER_SIZE = 10  # Size of data points
    MARKER_ALPHA = 0.7  # Transparency of markers (0-1)
    
    # Travel time plot axis limits
    # Set to None for automatic limits based on data
    DISTANCE_MIN = 0      # Minimum hypocenter distance (km)
    DISTANCE_MAX = 200    # Maximum hypocenter distance (km)
    TIME_MIN = 0          # Minimum travel time (s)
    TIME_MAX = 100        # Maximum travel time (s)
    
    # If AUTO_LIMITS is True, ignore above settings and calculate from data
    AUTO_LIMITS_DISTANCE = False
    AUTO_LIMITS_TIME = True
    
    # Filter data outside the limits (only when AUTO_LIMITS is False)
    FILTER_OUTSIDE_LIMITS = False  # If True, only plot data within configured limits
    
    # Trend line settings
    TREND_LINE_WIDTH = 2  # Width of trend lines
    TREND_LINE_STYLE = "--"  # Style of trend lines
    TREND_LINE_ALPHA = 0.7  # Transparency of trend lines
    
    # ==================== Figure Settings ====================
    # Figure sizes (inches)
    RAY_PATH_FIGSIZE = (12, 10)
    TRAVEL_TIME_FIGSIZE = (10, 7)
    
    # DPI settings for high-quality output
    FIGURE_DPI = 300
    SAVE_DPI = 300
    
    # Font settings
    FONT_FAMILY = "Arial"
    FONT_SIZE_BASE = 10
    TITLE_SIZE = 14
    LABEL_SIZE = 12
    TICK_SIZE = 10
    LEGEND_SIZE = 9
    
    # ==================== Color Schemes ====================
    # Topography colors
    LAND_COLOR = "#f0f0f0"
    OCEAN_COLOR = "#e6f2ff"
    COASTLINE_COLOR = "gray"
    BORDER_COLOR = "gray"
    
    # Grid settings
    GRID_COLOR = "gray"
    GRID_ALPHA = 0.3
    GRID_WIDTH = 0.5
    
    # ==================== Data Sampling ====================
    # Maximum number of events to plot (for large datasets)
    MAX_EVENTS_TO_PLOT = 30000  # Reasonable number of events
    
    # Maximum number of stations to plot
    MAX_STATIONS_TO_PLOT = 800  # Show all stations if possible
    
    # Maximum number of ray paths to plot
    MAX_RAYS_TO_PLOT = 600000  # Increased significantly for better coverage
    
    # ==================== Advanced Settings ====================
    # Minimum number of data points required for trend line fitting
    MIN_POINTS_FOR_TREND = 5
    
    # Polynomial degree for trend line fitting
    TREND_POLY_DEGREE = 1
    
    # Earth radius for distance calculations (km)
    EARTH_RADIUS = 6371.0
    
    # Scale bar length (km)
    SCALE_BAR_LENGTH = 50
    
    # ==================== Quality Control ====================
    # Maximum allowed travel time residual (seconds)
    MAX_RESIDUAL = 5.0
    
    # Minimum magnitude to display
    MIN_MAGNITUDE = 0.0
    
    # Maximum epicentral distance to consider (km)
    MAX_DISTANCE = 500.0
    
    # ==================== Localization ====================
    # Language for labels (EN/CN)
    LANGUAGE = "EN"
    
    # Labels in English
    LABELS_EN = {
        "ray_path_title": "Seismic Ray Path Distribution",
        "travel_time_title": "Seismic Wave Travel Time Analysis",
        "earthquake": "Earthquake",
        "station": "Station",
        "p_wave": "P-wave",
        "s_wave": "S-wave",
        "distance": "Hypocenter Distance (km)",
        "travel_time": "Travel Time (s)",
        "velocity_p": "Vp",
        "velocity_s": "Vs"
    }
    
    # Labels in Chinese (if needed)
    LABELS_CN = {
        "ray_path_title": "地震射线路径分布",
        "travel_time_title": "地震波走时分析",
        "earthquake": "地震",
        "station": "台站",
        "p_wave": "P波",
        "s_wave": "S波",
        "distance": "震源距离 (km)",
        "travel_time": "走时 (s)",
        "velocity_p": "P波速度",
        "velocity_s": "S波速度"
    }
    
    def get_label(self, key):
        """Get label based on language setting"""
        if self.LANGUAGE == "CN":
            return self.LABELS_CN.get(key, key)
        return self.LABELS_EN.get(key, key)
    
    # ==================== Data Processing ====================
    # Whether to apply quality control filters
    APPLY_QC = True
    
    # Whether to remove outliers
    REMOVE_OUTLIERS = True
    
    # Outlier detection method ('iqr', 'zscore', 'none')
    OUTLIER_METHOD = 'iqr'
    
    # Z-score threshold for outlier detection
    ZSCORE_THRESHOLD = 3.0
    
    # IQR multiplier for outlier detection
    IQR_MULTIPLIER = 1.5
    
    # ==================== Export Settings ====================
    # Additional export formats
    EXPORT_FORMATS = ['png']  # Can add 'pdf', 'svg', 'eps'
    
    # Whether to save processed data
    SAVE_PROCESSED_DATA = False
    
    # Processed data output format ('csv', 'json', 'pickle')
    DATA_OUTPUT_FORMAT = 'csv'
    
    # Output directory for all files
    OUTPUT_DIR = "."
    
    def __init__(self):
        """Initialize configuration and validate settings"""
        self.validate_settings()
    
    def validate_settings(self):
        """Validate configuration parameters"""
        assert self.RAY_ALPHA >= 0 and self.RAY_ALPHA <= 1, "RAY_ALPHA must be between 0 and 1"
        assert self.MARKER_ALPHA >= 0 and self.MARKER_ALPHA <= 1, "MARKER_ALPHA must be between 0 and 1"
        assert self.FIGURE_DPI > 0, "FIGURE_DPI must be positive"
        assert self.SAVE_DPI > 0, "SAVE_DPI must be positive"
        assert self.LANGUAGE in ['EN', 'CN'], "LANGUAGE must be 'EN' or 'CN'"
        assert self.OUTLIER_METHOD in ['iqr', 'zscore', 'none'], "Invalid OUTLIER_METHOD"
        
    def print_config(self):
        """Print current configuration settings"""
        print("=" * 50)
        print("Seismic Visualization Configuration")
        print("=" * 50)
        print(f"Input Phase File: {self.PHASE_FILE}")
        print(f"Input Station File: {self.STATION_FILE}")
        print(f"Output Ray Path: {self.OUTPUT_RAY_PATH}")
        print(f"Output Travel Time: {self.OUTPUT_TRAVEL_TIME}")
        if self.ENABLE_3D_VISUALIZATION:
            print(f"Output 3D Ray Path: {self.OUTPUT_3D_RAY_PATH}")
        print(f"Figure DPI: {self.FIGURE_DPI}")
        print("=" * 50)
        print("Map Layout:")
        print("  Main Map: Shows ALL data with ray paths")
        print(f"    Padding: ±{self.MAIN_MAP_PADDING}° around data extent")
        print("  Inset Map: Detailed view of study area")
        if self.AUTO_EXTENT:
            print("    Study Area: Using automatic extent from data")
        else:
            print(f"    Study Area Longitude: {self.MAP_LON_MIN}° to {self.MAP_LON_MAX}°")
            print(f"    Study Area Latitude: {self.MAP_LAT_MIN}° to {self.MAP_LAT_MAX}°")
        if self.ENABLE_3D_VISUALIZATION:
            print("=" * 50)
            print("3D Visualization Settings:")
            print(f"  Max Events: {self.MAX_EVENTS_3D}")
            print(f"  View Angles: Elev={self.VIEW_ELEV_3D}°, Azim={self.VIEW_AZIM_3D}°")
            print(f"  Max Depth: {self.MAX_DEPTH_3D} km")
        print("=" * 50)
        print("Visualization Settings:")
        print(f"  Max Events: {self.MAX_EVENTS_TO_PLOT}")
        print(f"  Max Stations: {self.MAX_STATIONS_TO_PLOT}")
        print(f"  Max Ray Paths: {self.MAX_RAYS_TO_PLOT}")
        print(f"  Event Marker: {self.EVENT_MARKER} (color: {self.EVENT_COLOR})")
        print("=" * 50)

# ==================== PRESET CONFIGURATIONS ====================
# Uncomment and modify one of these presets for quick setup

# Example 1: Tangshan region study (as shown in reference image)
# MAP_LON_MIN = 117.0  # Study area min longitude
# MAP_LON_MAX = 119.5  # Study area max longitude
# MAP_LAT_MIN = 39.0   # Study area min latitude  
# MAP_LAT_MAX = 40.5   # Study area max latitude
# AUTO_EXTENT = False
# DISTANCE_MAX = 300

# Example 2: Beijing-Tianjin-Hebei region
# MAP_LON_MIN = 115.0
# MAP_LON_MAX = 120.0  
# MAP_LAT_MIN = 38.0
# MAP_LAT_MAX = 42.0
# AUTO_EXTENT = False
# DISTANCE_MAX = 400

# Example 3: Automatic extent (let program determine from data)
# AUTO_EXTENT = True
# DISTANCE_MAX = 500